def millas_a_metros(m):
    return print("El resultado de su conversion es " + str(float(m * 1609.34)))

def millas_a_kilometros(m):
    return print("El resultado de su conversion es " + str(float(m * 1.60934)))

def millas_a_pies(m):
    return print("El resultado de su conversion es " + str(float(m * 5280)))