def pies_a_metros(p):
    return print("El resultado de su conversion es " + str(float(p / 3.28084)))

def pies_a_kilometros(p):
    return print("El resultado de su conversion es " + str(float(p / 3280.84)))

def pies_a_millas(p):
    return print("El resultado de su conversion es " + str(float(p / 5280)))