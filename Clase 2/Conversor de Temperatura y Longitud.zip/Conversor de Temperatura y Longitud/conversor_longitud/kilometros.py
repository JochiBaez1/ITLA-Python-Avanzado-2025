def kilom_a_metros(k):
    print("El resultado de su conversion es " + str(float(k * 1000)))

def kilom_a_millas(k):
    return print("El resultado de su conversion es " + str(float(k / 1.60934)))

def kilom_a_pies(k):
    return print("El resultado de su conversion es " + str(float(k * 3280.84)))
