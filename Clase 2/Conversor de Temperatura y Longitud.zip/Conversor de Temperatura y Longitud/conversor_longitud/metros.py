def metros_a_kilom(m):
    return print("El resultado de su conversion es " + str(float(m / 1000)))

def metros_a_millas(m):
    return print("El resultado de su conversion es " + str(float(m / 1609.34)))

def metros_a_pies(m):
    return print("El resultado de su conversion es " + str(float(m * 3.28084)))