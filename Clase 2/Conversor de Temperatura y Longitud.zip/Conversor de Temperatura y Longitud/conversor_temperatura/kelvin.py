def kelvin_a_celcius(k):
    return print("El resultado de su conversion es " + str(float(k - 273.15)))

def kelvin_a_fahrenheit(k):
    return print("El resultado de su conversion es " + str(float(k - 273.15) * 9/5 + 32))