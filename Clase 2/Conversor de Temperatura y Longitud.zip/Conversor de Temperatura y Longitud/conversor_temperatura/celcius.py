def celcius_a_fahren(c):
    return print("El resultado de su conversion es " + str(float((c * 9/5) + 32)))

def celcius_a_kelvin(c):
    return print("El resultado de su conversion es " + str(float(c + 273.15)))