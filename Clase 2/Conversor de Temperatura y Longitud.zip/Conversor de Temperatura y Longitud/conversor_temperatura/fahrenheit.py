def fahr_a_celcius(f):
    return print("El resultado de su conversion es " + str(float(f - 32) * 5/9))

def fahr_a_kelvin(f):
    return print("El resultado de su conversion es " + str(float(f - 32) * 5/9 + 273.15))